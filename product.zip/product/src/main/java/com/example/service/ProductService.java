package com.example.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.ProductDTO;
import com.example.entity.Product;
import com.example.repository.ProductRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
	 
@Service
public class ProductService {
	 
	    @Autowired
	    private ProductRepository productRepository;

	    public ProductDTO createProduct(ProductDTO productDTO) {
	        Product product = new Product();
	        product.setName(productDTO.getName());
	        product.setDescription(productDTO.getDescription());
	        product.setPrice(productDTO.getPrice());
	        product.setStock(productDTO.getStock());
	        Product savedProduct = productRepository.save(product);
	        return convertToDTO(savedProduct);
	    }
	 
	    public Optional<ProductDTO> getProductById(Long id) {
	        Optional<Product> product = productRepository.findById(id);
	        return product.map(this::convertToDTO);
	    }
	 
	    public List<ProductDTO> getAllProducts() {
	        List<Product> products = (List<Product>) productRepository.findAll();
	        return products.stream().map(this::convertToDTO).collect(Collectors.toList());
	    }
	 
	    public void updateStock(Long productId, int quantity) {
	    	Product product = productRepository.findById(productId).orElseThrow(()-> new RuntimeException("product not found"));
	    	int newStock = product.getStock() - quantity;
	    	product.setStock(newStock);
	    	productRepository.save(product);
	    }
	 
	    public void deleteProduct(Long id) {
	        productRepository.deleteById(id);
	    }
	 
	    private ProductDTO convertToDTO(Product product) {
	        ProductDTO productDTO = new ProductDTO();
	        productDTO.setId(product.getId());
	        productDTO.setName(product.getName());
	        productDTO.setDescription(product.getDescription());
	        productDTO.setPrice(product.getPrice());
	        productDTO.setStock(product.getStock());
	        return productDTO;
	    }
	    
	    private Product convertToEntity(ProductDTO productDTO) {
	        Product product = new Product();
	        product.setId(product.getId());
	        product.setName(product.getName());
	        product.setDescription(product.getDescription());
	        product.setPrice(product.getPrice());
	        product.setStock(product.getStock());
	        return product;
	    }
	}

