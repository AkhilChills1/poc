package com.example.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.dto.ProductDTO;
import com.example.service.ProductService;

import java.util.List;
import java.util.Optional;
	 
@RestController
@RequestMapping("/products")
public class ProductController {
	 
	    
	 
	    @Autowired
	    private ProductService productService;
	 
	    @PostMapping
	    public ResponseEntity<ProductDTO> createProduct(@RequestBody ProductDTO productDTO) {
	        ProductDTO createdProduct = productService.createProduct(productDTO);
	        return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
	    }
	 
	    @GetMapping("/get/{id}")
	    public ResponseEntity<ProductDTO> getProductById(@PathVariable Long id) {
	        Optional<ProductDTO> product = productService.getProductById(id);
	        return product.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
	                      .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
	    }
	 
	    @GetMapping
	    public ResponseEntity<List<ProductDTO>> getAllProducts() {
	        List<ProductDTO> products = productService.getAllProducts();
	        return new ResponseEntity<>(products, HttpStatus.OK);
	    }
	 
	    @PutMapping("update-stock/{productId}/{quantity}")
	    public ResponseEntity<Void> updateProduct(@PathVariable Long productId, @PathVariable int quantity) {
	        productService.updateStock(productId, quantity);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	 
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
	        productService.deleteProduct(id);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	
}
