//package com.example.rabbitmq;
//
//import org.springframework.amqp.core.Binding;
//import org.springframework.amqp.core.BindingBuilder;
//import org.springframework.amqp.core.DirectExchange;
//import org.springframework.amqp.core.Queue;
//import org.springframework.amqp.rabbit.connection.ConnectionFactory;
//import org.springframework.amqp.rabbit.core.RabbitTemplate;
//import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
//import org.springframework.amqp.support.converter.MessageConverter;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class RabbitMQConfiguration {
//	
//	public static final String ORDER_QUEUE = "order-queue";
//    public static final String PRODUCT_UPDATE_QUEUE = "product-update-queue";
//    public static final String PRODUCT_DELETE_QUEUE = "product-delete-queue";
//    public static final String ORDER_EXCHANGE = "order-exchange";
//    public static final String PRODUCT_EXCHANGE = "product-exchange";
//    public static final String ORDER_ROUTING_KEY = "order-routing-key";
//    public static final String PRODUCT_UPDATE_ROUTING_KEY = "product-update-routing-key";
//    public static final String PRODUCT_DELETE_ROUTING_KEY = "product-delete-routing-key";
// 
//    @Bean
//    public Queue orderQueue() {
//        return new Queue(ORDER_QUEUE, true);
//    }
// 
//    @Bean
//    public Queue productUpdateQueue() {
//        return new Queue(PRODUCT_UPDATE_QUEUE, true);
//    }
// 
//    @Bean
//    public Queue productDeleteQueue() {
//        return new Queue(PRODUCT_DELETE_QUEUE, true);
//    }
// 
//    @Bean
//    public DirectExchange orderExchange() {
//        return new DirectExchange(ORDER_EXCHANGE);
//    }
// 
//    @Bean
//    public DirectExchange productExchange() {
//        return new DirectExchange(PRODUCT_EXCHANGE);
//    }
// 
//    @Bean
//    public Binding orderBinding(Queue orderQueue, DirectExchange orderExchange) {
//        return BindingBuilder.bind(orderQueue).to(orderExchange).with(ORDER_ROUTING_KEY);
//    }
// 
//    @Bean
//    public Binding productUpdateBinding(Queue productUpdateQueue, DirectExchange productExchange) {
//        return BindingBuilder.bind(productUpdateQueue).to(productExchange).with(PRODUCT_UPDATE_ROUTING_KEY);
//    }
// 
//    @Bean
//    public Binding productDeleteBinding(Queue productDeleteQueue, DirectExchange productExchange) {
//        return BindingBuilder.bind(productDeleteQueue).to(productExchange).with(PRODUCT_DELETE_ROUTING_KEY);
//    }
// 
//    @Bean
//    public MessageConverter jsonMessageConverter() {
//        return  new Jackson2JsonMessageConverter();
//    }
// 
//    @Bean
//    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
//        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
//        rabbitTemplate.setMessageConverter(jsonMessageConverter());
//        return rabbitTemplate;
//    }
//
//}
